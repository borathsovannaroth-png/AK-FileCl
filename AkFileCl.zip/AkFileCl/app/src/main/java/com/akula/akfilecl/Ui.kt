package com.akula.akfilecl

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.text.DateFormat
import java.util.Date

sealed class Dlg {
    data class Rename(val f: File) : Dlg()
    data class Delete(val fs: List<File>) : Dlg()
    data class Info(val f: File) : Dlg()
    data class Compress(val fs: List<File>) : Dlg()
    data class View(val f: File) : Dlg()
    data class ExtractTo(val f: File) : Dlg()
    object Shizuku : Dlg()
}

private fun shizukuState(): String = try {
    if (!Shizuku.pingBinder()) "Shizuku is not running"
    else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "Connected to Shizuku"
    else "Shizuku running - permission needed"
} catch (e: Throwable) { "Shizuku not installed" }

private data class Tile(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val onClick: () -> Unit)

private val EXT_FILTERS = listOf("All", "apk", "pdf", "mp3", "png", "jpg", "mp4", "zip", "txt")
private val DATE_FILTERS = listOf("Any date", "Last 24 h", "Last 7 days", "Last 30 days")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AkApp(act: ComponentActivity, themeMode: ThemeMode, onTheme: (ThemeMode) -> Unit) {
    val ctx = act
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("ak", 0) }
    val primaryRoot = remember { Environment.getExternalStorageDirectory() }
    val loader = remember {
        ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.crossfade(true).build()
    }

    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var tick by remember { mutableIntStateOf(0) }
    var showCredit by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf<Item?>(null) }
    var sheet by remember { mutableStateOf<Item?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var clip by remember { mutableStateOf<Pair<List<File>, Boolean>?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var grid by remember { mutableStateOf(prefs.getBoolean("grid", false)) }
    var sort by remember { mutableStateOf(SortBy.values().getOrElse(prefs.getInt("sort", 0)) { SortBy.Name }) }
    var chip by remember { mutableStateOf<Cat?>(null) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var extF by remember { mutableStateOf("All") }
    var dateF by remember { mutableIntStateOf(0) }
    var selectMode by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var menuOpen by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }

    val hasAccess = remember(tick) {
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    // ---- storage volumes (background) ----
    val vols by produceState(emptyList<Vol>(), tick, hasAccess) {
        value = withContext(Dispatchers.IO) { loadVolumes(ctx) }
    }

    // ---- file list loading (background threads, cancellable, debounced search) ----
    val searchActive = searching && (query.isNotBlank() || extF != "All" || dateF != 0)
    val loadKey: Any = if (searching) listOf("s", query, extF, dateF) else listOf(screen, chip)
    var result by remember { mutableStateOf<Pair<Any, List<Item>>?>(null) }
    LaunchedEffect(loadKey, tick, sort, hasAccess) {
        if (!hasAccess) return@LaunchedEffect
        val s = screen
        val c = chip
        val so = sort
        val q = query.trim().lowercase()
        val ef = extF
        val df = dateF
        val isSearch = searching
        val active = searchActive
        val roots = vols.map { it.root }.ifEmpty { listOf(primaryRoot) }
        if (isSearch) delay(300)
        val list: List<Item> = withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            when {
                isSearch -> {
                    if (!active) emptyList()
                    else {
                        val since = when (df) { 1 -> now - DAY; 2 -> now - 7 * DAY; 3 -> now - 30 * DAY; else -> 0L }
                        roots.flatMap { r ->
                            scan(r, 12, 400) { f ->
                                (q.isEmpty() || f.name.lowercase().contains(q)) &&
                                    (ef == "All" || f.extension.equals(ef, true)) && f.lastModified() >= since
                            }
                        }.map { it.toItem() }.sortedByDescending { it.mod }
                    }
                }
                s is Screen.Browse -> {
                    val all = (s.dir.listFiles()?.toList() ?: emptyList()).filter { !it.name.startsWith(".") }
                    val base = if (c == null) all else all.filter { !it.isDirectory && catOf(it) == c }
                    base.map { it.toItem() }.sortedWith(
                        compareBy<Item> { !it.dir }.thenComparator { a, b ->
                            when (so) {
                                SortBy.Name -> a.file.name.lowercase().compareTo(b.file.name.lowercase())
                                SortBy.Size -> b.size.compareTo(a.size)
                                SortBy.Date -> b.mod.compareTo(a.mod)
                            }
                        }
                    )
                }
                s is Screen.Category ->
                    roots.flatMap { r -> scan(r, 12, 3000) { f -> catOf(f) == s.cat } }
                        .map { it.toItem() }.sortedByDescending { it.mod }
                s is Screen.Recents ->
                    roots.flatMap { r -> scan(r, 6, 400) { f -> f.lastModified() >= now - DAY } }
                        .map { it.toItem() }.sortedByDescending { it.mod }.take(150)
                else -> emptyList()
            }
        }
        result = loadKey to list
    }
    val shown: List<Item>? = result?.takeIf { it.first == loadKey }?.second

    val onHome = screen is Screen.Home
    val recents by produceState<List<Item>?>(null, tick, hasAccess, onHome) {
        if (hasAccess && onHome) {
            value = withContext(Dispatchers.IO) {
                scan(primaryRoot, 6, 400) { it.lastModified() >= System.currentTimeMillis() - DAY }
                    .map { it.toItem() }.sortedByDescending { it.mod }.take(30)
            }
        }
    }

    // ---- helpers ----
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun runOp(ok: String, block: () -> Unit) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(block) }
            toast(r.fold({ ok }, { "Error: ${it.message}" }))
            tick++
        }
    }
    fun exitSelect() { selectMode = false; sel = emptySet() }
    fun go(s: Screen) { screen = s; chip = null; searching = false; query = ""; exitSelect() }
    fun closeMenus() { menu = null; sheet = null }
    fun uri(f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
    fun mime(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    fun openFile(f: File) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri(f), mime(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }.onFailure { toast("No app can open this file") }
        closeMenus()
    }
    fun shareFiles(fs: List<File>) {
        val files = fs.filter { it.isFile }
        if (files.isEmpty()) { toast("Select files (not folders) to share"); return }
        runCatching {
            val i = if (files.size == 1) Intent(Intent.ACTION_SEND).setType(mime(files[0])).putExtra(Intent.EXTRA_STREAM, uri(files[0]))
            else Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { uri(it) }))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "Share"))
        }
        closeMenus(); exitSelect()
    }
    fun quick(f: File, fmt: String) {
        val base = if (f.isDirectory) f.name else f.nameWithoutExtension
        val out = Archiver.unique(File(f.parentFile, "$base.$fmt"))
        runOp("Created ${out.name}") { Archiver.compress(listOf(f), out, fmt) }
        closeMenus()
    }
    fun paste() {
        val c = clip ?: return
        val s = screen as? Screen.Browse ?: return
        val target = s.dir
        runOp("Pasted") {
            c.first.forEach {
                val t = Archiver.unique(File(target, it.name))
                if (c.second) { if (!it.renameTo(t)) { it.copyRecursively(t); it.deleteRecursively() } }
                else it.copyRecursively(t)
            }
        }
        if (c.second) clip = null
    }
    fun setFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s).apply() }
    fun onTap(it: Item) {
        if (selectMode) { sel = if (it.file.path in sel) sel - it.file.path else sel + it.file.path; return }
        if (it.dir) go(Screen.Browse(it.file)) else sheet = it
    }
    fun onLong(it: Item) { menu = it }

    BackHandler(enabled = searching || selectMode || screen !is Screen.Home) {
        when {
            searching -> { searching = false; query = "" }
            selectMode -> exitSelect()
            else -> {
                val s = screen
                if (s is Screen.Browse && vols.none { it.root.path == s.dir.path }) {
                    val p = s.dir.parentFile
                    go(if (p != null) Screen.Browse(p) else Screen.Home)
                } else go(Screen.Home)
            }
        }
    }

    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) runCatching { focus.requestFocus() } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            val bar = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                titleContentColor = MaterialTheme.colorScheme.onSurface,
                navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
                actionIconContentColor = MaterialTheme.colorScheme.onSurface
            )
            when {
                selectMode -> TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                    title = { Text("${sel.size} selected") },
                    navigationIcon = { IconButton({ exitSelect() }) { Icon(Icons.Filled.Close, "Cancel selection") } },
                    actions = {
                        IconButton({ sel = (shown ?: emptyList()).map { it.file.path }.toSet() }) { Icon(Icons.Filled.SelectAll, "Select all") }
                        IconButton({ if (sel.isNotEmpty()) { clip = sel.map { File(it) } to false; toast("Copied"); exitSelect() } }) { Icon(Icons.Filled.ContentCopy, "Copy") }
                        IconButton({ if (sel.isNotEmpty()) { clip = sel.map { File(it) } to true; toast("Cut"); exitSelect() } }) { Icon(Icons.Filled.ContentCut, "Cut") }
                        IconButton({ if (sel.isNotEmpty()) dlg = Dlg.Delete(sel.map { File(it) }) }) { Icon(Icons.Filled.Delete, "Delete") }
                        Box {
                            IconButton({ moreOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                            DropdownMenu(moreOpen, { moreOpen = false }) {
                                DropdownMenuItem(text = { Text("Share") }, leadingIcon = { Icon(Icons.Filled.Share, null) },
                                    onClick = { moreOpen = false; shareFiles(sel.map { File(it) }) })
                                DropdownMenuItem(text = { Text("Compress...") }, leadingIcon = { Icon(Icons.Filled.Archive, null) },
                                    onClick = { moreOpen = false; if (sel.isNotEmpty()) dlg = Dlg.Compress(sel.map { File(it) }) })
                            }
                        }
                    }
                )
                searching -> TopAppBar(
                    colors = bar,
                    title = {
                        TextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            placeholder = { Text("Search all files") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus)
                        )
                    },
                    navigationIcon = { IconButton({ searching = false; query = "" }) { Icon(Icons.Filled.ArrowBack, "Close search") } },
                    actions = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, "Clear") } }
                )
                else -> TopAppBar(
                    colors = bar,
                    title = {
                        Text(
                            when (val s = screen) {
                                Screen.Home -> "AkFileCl"
                                is Screen.Browse -> s.dir.name.ifEmpty { "Storage" }
                                is Screen.Category -> s.cat.label
                                Screen.Recents -> "Recent files"
                            }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    navigationIcon = {
                        if (screen !is Screen.Home) IconButton({
                            val s = screen
                            if (s is Screen.Browse && vols.none { it.root.path == s.dir.path }) {
                                val p = s.dir.parentFile
                                go(if (p != null) Screen.Browse(p) else Screen.Home)
                            } else go(Screen.Home)
                        }) { Icon(Icons.Filled.ArrowBack, "Back") }
                    },
                    actions = {
                        IconButton({ searching = true }) { Icon(Icons.Filled.Search, "Search") }
                        if (screen !is Screen.Home) IconButton({ grid = !grid; prefs.edit().putBoolean("grid", grid).apply() }) {
                            Icon(if (grid) Icons.Filled.ViewList else Icons.Filled.GridView, "Grid / list")
                        }
                        if (clip != null && screen is Screen.Browse) IconButton({ paste() }) { Icon(Icons.Filled.ContentPaste, "Paste") }
                        Box {
                            IconButton({ menuOpen = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                            DropdownMenu(menuOpen, { menuOpen = false }) {
                                if (screen !is Screen.Home) DropdownMenuItem(text = { Text("Select") },
                                    leadingIcon = { Icon(Icons.Filled.CheckBox, null) },
                                    onClick = { menuOpen = false; selectMode = true })
                                DropdownMenuItem(text = { Text("Sort: ${sort.label}") },
                                    leadingIcon = { Icon(Icons.Filled.Sort, null) },
                                    onClick = {
                                        menuOpen = false
                                        val all = SortBy.values()
                                        sort = all[(sort.ordinal + 1) % all.size]
                                        prefs.edit().putInt("sort", sort.ordinal).apply()
                                    })
                                DropdownMenuItem(text = { Text("Theme: ${themeMode.label}") },
                                    leadingIcon = { Icon(Icons.Filled.Palette, null) },
                                    onClick = {
                                        menuOpen = false
                                        val all = ThemeMode.values()
                                        onTheme(all[(themeMode.ordinal + 1) % all.size])
                                    })
                                DropdownMenuItem(text = { Text("Shizuku") }, leadingIcon = { Icon(Icons.Filled.Bolt, null) },
                                    onClick = { menuOpen = false; dlg = Dlg.Shizuku })
                                DropdownMenuItem(text = { Text("About / Credits") }, leadingIcon = { Icon(Icons.Filled.Info, null) },
                                    onClick = { menuOpen = false; showCredit = true })
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!hasAccess) {
                EmptyState(Icons.Filled.Lock, "Permission needed",
                    "AkFileCl needs file access to show and manage your files.") {
                    Button({
                        if (Build.VERSION.SDK_INT >= 30) {
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:${ctx.packageName}")))
                        } else ctx.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                    }) { Text("Grant access") }
                }
            } else if (searching) {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(EXT_FILTERS) { e ->
                        FilterChip(selected = extF == e, onClick = { extF = e }, label = { Text(if (e == "All") "All types" else ".$e") })
                    }
                }
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(DATE_FILTERS.size) { i ->
                        FilterChip(selected = dateF == i, onClick = { dateF = i }, label = { Text(DATE_FILTERS[i]) })
                    }
                }
                FileList(
                    if (searchActive) shown else emptyList(), grid, loader, selectMode, sel,
                    Icons.Filled.Search,
                    if (searchActive) "No search results found" else "Search your phone",
                    if (searchActive) "Try another keyword or filter." else "Type a name, or pick a file type or date.",
                    Modifier.weight(1f), { onTap(it) }, { onLong(it) })
            } else when (val s = screen) {
                Screen.Home -> LazyColumn(
                    Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(vols, key = { it.root.path }) { v ->
                        StorageCard(v, Modifier.fillMaxWidth()) { go(Screen.Browse(v.root)) }
                    }
                    item { Text("Categories", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface) }
                    item {
                        val tiles = listOf(
                            Tile("Images", Icons.Filled.Image) { go(Screen.Category(Cat.Images)) },
                            Tile("Videos", Icons.Filled.Videocam) { go(Screen.Category(Cat.Videos)) },
                            Tile("Audio", Icons.Filled.MusicNote) { go(Screen.Category(Cat.Audio)) },
                            Tile("Documents", Icons.Filled.Description) { go(Screen.Category(Cat.Docs)) },
                            Tile("APKs", Icons.Filled.Android) { go(Screen.Category(Cat.Apks)) },
                            Tile("Downloads", Icons.Filled.Download) { go(Screen.Browse(File(primaryRoot, "Download"))) }
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            tiles.chunked(3).forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    row.forEach { t -> CategoryCard(t.label, t.icon, Modifier.weight(1f)) { t.onClick() } }
                                }
                            }
                        }
                    }
                    if (favs.isNotEmpty()) {
                        item { Text("Favorites", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface) }
                        items(favs.sorted(), key = { "f:$it" }) { p ->
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = 56.dp)
                                    .clickable { go(Screen.Browse(File(p))) },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Star, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(File(p).name, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                    Text(p, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis)
                                }
                                IconButton({ setFavs(favs - p) }) { Icon(Icons.Filled.Close, "Remove favorite") }
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Recent (last 24 h)", style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                            TextButton({ go(Screen.Recents) }) { Text("See all") }
                        }
                    }
                    val rc = recents
                    if (rc == null) item { CircularProgressIndicator(Modifier.size(28.dp)) }
                    else if (rc.isEmpty()) item {
                        Text("No files changed in the last 24 hours.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else items(rc.take(8), key = { "r:" + it.file.path }) { r ->
                        FileRow(r, loader, false, false, { onTap(r) }, { onLong(r) })
                    }
                }
                is Screen.Browse -> {
                    BreadcrumbBar(vols.firstOrNull { s.dir.path.startsWith(it.root.path) }, s.dir) { go(Screen.Browse(it)) }
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected = chip == null, onClick = { chip = null }, label = { Text("All") }) }
                        items(Cat.values().toList()) { c ->
                            FilterChip(selected = chip == c, onClick = { chip = c }, label = { Text(c.label) })
                        }
                    }
                    FileList(shown, grid, loader, selectMode, sel,
                        Icons.Filled.FolderOpen, "This folder is empty",
                        if (chip != null) "No ${chip!!.label.lowercase()} in this folder." else "Nothing here yet.",
                        Modifier.weight(1f), { onTap(it) }, { onLong(it) })
                }
                is Screen.Category -> FileList(shown, s.cat == Cat.Images || s.cat == Cat.Videos || grid, loader, selectMode, sel,
                    s.cat.icon, "No ${s.cat.label.lowercase()} found", "Nothing of this type on your storage.",
                    Modifier.weight(1f), { onTap(it) }, { onLong(it) })
                Screen.Recents -> FileList(shown, grid, loader, selectMode, sel,
                    Icons.Filled.Schedule, "Nothing recent", "No files changed in the last 24 hours.",
                    Modifier.weight(1f), { onTap(it) }, { onLong(it) })
            }
        }
    }

    // ---- Long-press action sheet ----
    menu?.let { m ->
        val f = m.file
        ModalBottomSheet(onDismissRequest = { menu = null }, containerColor = MaterialTheme.colorScheme.surfaceContainer) {
            Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding()) {
                SheetTitle(f.name)
                MenuItem(Icons.Filled.CheckBox, "Select multiple") {
                    selectMode = true; sel = setOf(f.path); closeMenus()
                }
                if (screen !is Screen.Browse) MenuItem(Icons.Filled.FolderOpen, "Open containing folder") {
                    f.parentFile?.let { go(Screen.Browse(it)) }; closeMenus()
                }
                if (f.isDirectory) {
                    MenuItem(Icons.Filled.Archive, "Compress to *.zip") { quick(f, "zip") }
                    MenuItem(Icons.Filled.Archive, "Compress to *.7z") { quick(f, "7z") }
                } else {
                    MenuItem(Icons.Filled.Visibility, "Open with") { openFile(f) }
                    MenuItem(Icons.Filled.Unarchive, "Open as archive") { dlg = Dlg.View(f); closeMenus() }
                }
                MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(listOf(f)); closeMenus() }
                MenuItem(Icons.Filled.ContentCopy, "Copy") { clip = listOf(f) to false; toast("Copied"); closeMenus() }
                MenuItem(Icons.Filled.ContentCut, "Cut") { clip = listOf(f) to true; toast("Cut"); closeMenus() }
                MenuItem(Icons.Filled.Delete, "Delete") { dlg = Dlg.Delete(listOf(f)); closeMenus() }
                MenuItem(Icons.Filled.Edit, "Rename") { dlg = Dlg.Rename(f); closeMenus() }
                MenuItem(Icons.Filled.Info, "Properties") { dlg = Dlg.Info(f); closeMenus() }
                if (f.isDirectory) {
                    if (f.path in favs) MenuItem(Icons.Filled.StarBorder, "Remove from Favorites") { setFavs(favs - f.path); closeMenus() }
                    else MenuItem(Icons.Filled.Star, "Add to Favorites") { setFavs(favs + f.path); toast("Added to Favorites"); closeMenus() }
                } else MenuItem(Icons.Filled.Share, "Share") { shareFiles(listOf(f)) }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // ---- Tap sheet (archive / other file) ----
    sheet?.let { m ->
        val f = m.file
        ModalBottomSheet(onDismissRequest = { sheet = null }, containerColor = MaterialTheme.colorScheme.surfaceContainer) {
            Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding()) {
                SheetTitle(f.name)
                if (Archiver.isArchive(f)) {
                    MenuItem(Icons.Filled.Visibility, "View") { dlg = Dlg.View(f); closeMenus() }
                    MenuItem(Icons.Filled.Unarchive, "Extract here") {
                        runOp("Extracted") { Archiver.extract(f, f.parentFile!!) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Unarchive, "Extract to ./<Archive name>/") {
                        runOp("Extracted") { Archiver.extract(f, File(f.parentFile, f.nameWithoutExtension)) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Unarchive, "Extract...") { dlg = Dlg.ExtractTo(f); closeMenus() }
                    MenuItem(Icons.Filled.CheckBox, "Test") {
                        runOp("Archive is OK") { Archiver.test(f, ctx.cacheDir) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(listOf(f)); closeMenus() }
                } else {
                    MenuItem(Icons.Filled.Visibility, "Open") { openFile(f) }
                    MenuItem(Icons.Filled.Archive, "Compress to *.zip") { quick(f, "zip") }
                    MenuItem(Icons.Filled.Archive, "Compress to *.7z") { quick(f, "7z") }
                    MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(listOf(f)); closeMenus() }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // ---- Dialogs ----
    when (val d = dlg) {
        null -> {}
        is Dlg.Rename -> TextDlg("Rename", d.f.name, { dlg = null }) { n ->
            if (n.isNotEmpty()) runOp("Renamed") { if (!d.f.renameTo(File(d.f.parentFile, n))) error("Rename failed") }
            dlg = null
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Delete") },
            text = { Text(if (d.fs.size == 1) "Delete \"${d.fs[0].name}\"? This cannot be undone." else "Delete ${d.fs.size} items? This cannot be undone.") },
            confirmButton = { TextButton({ runOp("Deleted") { d.fs.forEach { it.deleteRecursively() } }; dlg = null; exitSelect() }) { Text("Delete") } },
            dismissButton = { TextButton({ dlg = null }) { Text("Cancel") } })
        is Dlg.ExtractTo -> TextDlg("Extract to", d.f.parent ?: "", { dlg = null }) { p ->
            runOp("Extracted") { Archiver.extract(d.f, File(p)) }; dlg = null
        }
        is Dlg.Compress -> CompressDlg(d.fs, { dlg = null }) { name, fmt ->
            val out = Archiver.unique(File(d.fs[0].parentFile, "$name.$fmt"))
            runOp("Created ${out.name}") { Archiver.compress(d.fs, out, fmt) }; dlg = null; exitSelect()
        }
        is Dlg.Info -> {
            val size by produceState("Calculating...", d) {
                value = withContext(Dispatchers.IO) {
                    Formatter.formatFileSize(ctx, d.f.walkTopDown().filter { it.isFile }.sumOf { it.length() })
                }
            }
            AlertDialog(onDismissRequest = { dlg = null }, title = { Text("Properties") },
                text = {
                    Text("Name: ${d.f.name}\nPath: ${d.f.path}\nType: ${if (d.f.isDirectory) "Folder" else d.f.extension.ifEmpty { "File" }}\n" +
                        "Size: $size\nModified: ${DateFormat.getDateTimeInstance().format(Date(d.f.lastModified()))}")
                },
                confirmButton = { TextButton({ dlg = null }) { Text("OK") } })
        }
        is Dlg.View -> {
            val names by produceState<List<String>?>(null, d) {
                value = withContext(Dispatchers.IO) { runCatching { Archiver.list(d.f) }.getOrElse { listOf("Cannot read: ${it.message}") } }
            }
            AlertDialog(onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1) },
                text = {
                    if (names == null) Text("Reading...") else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                        items(names!!.take(500)) { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                },
                confirmButton = { TextButton({ dlg = null }) { Text("Close") } })
        }
        Dlg.Shizuku -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Shizuku") },
            text = { Text(shizukuState() + "\n\nStart Shizuku, then tap Connect to grant AkFileCl permission.") },
            confirmButton = {
                TextButton({
                    runCatching {
                        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                            Shizuku.requestPermission(100)
                        else if (!Shizuku.pingBinder())
                            ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
                    }
                    dlg = null
                }) { Text("Connect") }
            },
            dismissButton = { TextButton({ dlg = null }) { Text("Close") } })
    }

    if (showCredit) CreditPopup { showCredit = false }
}
