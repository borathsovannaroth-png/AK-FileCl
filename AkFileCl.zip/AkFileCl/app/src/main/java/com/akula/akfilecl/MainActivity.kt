package com.akula.akfilecl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ak", 0)
        setContent {
            var mode by remember {
                mutableStateOf(ThemeMode.values().getOrElse(prefs.getInt("theme", 0)) { ThemeMode.System })
            }
            AkTheme(mode) {
                AkApp(this, mode) {
                    mode = it
                    prefs.edit().putInt("theme", it.ordinal).apply()
                }
            }
        }
    }
}
