package com.akula.akfilecl

import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Archiver {
    val exts = listOf(".zip", ".7z", ".tar", ".tar.gz", ".tgz", ".jar", ".apk")
    fun isArchive(f: File) = f.isFile && exts.any { f.name.lowercase().endsWith(it) }

    fun unique(f: File): File {
        if (!f.exists()) return f
        val base = f.name.substringBefore('.')
        val ext = f.name.removePrefix(base)
        var i = 1
        while (true) {
            val c = File(f.parentFile, "$base ($i)$ext")
            if (!c.exists()) return c
            i++
        }
    }

    fun compress(sources: List<File>, out: File, fmt: String) {
        when (fmt) {
            "zip" -> ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
                sources.forEach { addZip(z, it, it.parentFile!!) }
            }
            "7z" -> SevenZOutputFile(out).use { s ->
                sources.forEach { add7z(s, it, it.parentFile!!) }
            }
            "tar" -> TarArchiveOutputStream(BufferedOutputStream(FileOutputStream(out))).use { t ->
                t.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                sources.forEach { addTar(t, it, it.parentFile!!) }
            }
        }
    }

    private fun rel(f: File, base: File) = f.relativeTo(base).path.replace('\\', '/')

    private fun addZip(z: ZipOutputStream, f: File, base: File) {
        if (f.isDirectory) {
            z.putNextEntry(ZipEntry(rel(f, base) + "/")); z.closeEntry()
            f.listFiles()?.forEach { addZip(z, it, base) }
        } else {
            z.putNextEntry(ZipEntry(rel(f, base)))
            FileInputStream(f).use { it.copyTo(z) }
            z.closeEntry()
        }
    }

    private fun add7z(s: SevenZOutputFile, f: File, base: File) {
        s.putArchiveEntry(s.createArchiveEntry(f, rel(f, base)))
        if (f.isFile) {
            FileInputStream(f).use { i ->
                val b = ByteArray(8192); var r: Int
                while (i.read(b).also { r = it } >= 0) s.write(b, 0, r)
            }
        }
        s.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { add7z(s, it, base) }
    }

    private fun addTar(t: TarArchiveOutputStream, f: File, base: File) {
        t.putArchiveEntry(TarArchiveEntry(f, rel(f, base)))
        if (f.isFile) FileInputStream(f).use { it.copyTo(t) }
        t.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTar(t, it, base) }
    }

    private fun open(a: File): ArchiveInputStream {
        var ins: InputStream = BufferedInputStream(FileInputStream(a))
        val n = a.name.lowercase()
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) ins = BufferedInputStream(GzipCompressorInputStream(ins))
        return ArchiveStreamFactory().createArchiveInputStream(ins)
    }

    private fun safe(dest: File, name: String): File {
        val f = File(dest, name).canonicalFile
        require(f.path.startsWith(dest.canonicalPath)) { "Unsafe path in archive: $name" }
        return f
    }

    fun extract(a: File, dest: File) {
        dest.mkdirs()
        if (a.name.lowercase().endsWith(".7z")) {
            SevenZFile(a).use { s ->
                var e = s.nextEntry
                while (e != null) {
                    val f = safe(dest, e.name)
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { o ->
                            val b = ByteArray(8192); var r: Int
                            while (s.read(b).also { r = it } >= 0) o.write(b, 0, r)
                        }
                    }
                    e = s.nextEntry
                }
            }
        } else {
            open(a).use { s ->
                var e = s.nextEntry
                while (e != null) {
                    val f = safe(dest, e.name)
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { s.copyTo(it) }
                    }
                    e = s.nextEntry
                }
            }
        }
    }

    fun list(a: File): List<String> {
        val out = ArrayList<String>()
        if (a.name.lowercase().endsWith(".7z")) {
            SevenZFile(a).use { s -> var e = s.nextEntry; while (e != null) { out += e.name; e = s.nextEntry } }
        } else {
            open(a).use { s -> var e = s.nextEntry; while (e != null) { out += e.name; e = s.nextEntry } }
        }
        return out
    }

    fun test(a: File, cache: File) {
        val tmp = File(cache, "test_${System.nanoTime()}")
        try { extract(a, tmp) } finally { tmp.deleteRecursively() }
    }
}
