package com.akula.akfilecl

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

enum class PrivStatus(val label: String) {
    NotInstalled("Shizuku is not installed"),
    NotRunning("Shizuku is not running"),
    NeedPermission("Shizuku is running - permission needed"),
    Connecting("Connecting to Shizuku..."),
    Ready("Connected to Shizuku"),
    Unsupported("Shizuku version is too old")
}

/** Talks to Shizuku and to our file service that runs inside the Shizuku process. */
object Priv {
    var status by mutableStateOf(PrivStatus.NotRunning)
        private set
    var identity by mutableStateOf("")
        private set

    @Volatile
    private var svc: IShellService? = null
    private var app: Context? = null
    private var inited = false
    private var binding = false
    private val main = Handler(Looper.getMainLooper())

    val ready: Boolean get() = status == PrivStatus.Ready && svc != null

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        try {
            Shizuku.addBinderReceivedListenerSticky { post { refresh() } }
            Shizuku.addBinderDeadListener {
                svc = null
                binding = false
                post { refresh() }
            }
            Shizuku.addRequestPermissionResultListener { _, _ -> post { refresh() } }
        } catch (_: Throwable) {
        }
        refresh()
    }

    private fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (_: Throwable) {
        false
    }

    fun refresh() {
        val ctx = app ?: return
        status = try {
            if (!Shizuku.pingBinder()) {
                svc = null
                binding = false
                if (installed(ctx)) PrivStatus.NotRunning else PrivStatus.NotInstalled
            } else if (Shizuku.isPreV11()) {
                PrivStatus.Unsupported
            } else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                PrivStatus.NeedPermission
            } else if (svc != null) {
                PrivStatus.Ready
            } else {
                bind(ctx)
                PrivStatus.Connecting
            }
        } catch (_: Throwable) {
            PrivStatus.NotRunning
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(100)
        } catch (_: Throwable) {
        }
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            if (binder != null && binder.pingBinder()) {
                val s = IShellService.Stub.asInterface(binder)
                svc = s
                identity = try {
                    when (val u = s.uid()) {
                        0 -> "root"
                        2000 -> "ADB (shell)"
                        else -> "uid $u"
                    }
                } catch (_: Throwable) {
                    ""
                }
                status = PrivStatus.Ready
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            binding = false
            post { refresh() }
        }
    }

    private fun bind(ctx: Context) {
        if (binding) return
        binding = true
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .tag("akfilecl_shell")
            .version(3)
        Shizuku.bindUserService(args, conn)
    }

    private fun s(): IShellService = svc ?: throw IllegalStateException("Shizuku is not connected")

    // ---- blocking calls: use from a background thread only ----

    fun list(path: String): List<Item>? {
        val arr = s().list(path)
        if (arr.size == 1 && arr[0] == "ERR") return null
        val out = ArrayList<Item>(arr.size)
        for (line in arr) {
            val p = line.split('|', limit = 4)
            if (p.size < 4) continue
            val dir = p[0] == "1"
            out.add(Item(File(path, p[3]), dir, if (dir) 0L else (p[1].toLongOrNull() ?: 0L), -1, p[2].toLongOrNull() ?: 0L))
        }
        return out
    }

    fun stat(path: String): LongArray = s().stat(path)
    fun delete(path: String): Boolean = s().delete(path)
    fun rename(from: String, to: String): Boolean = s().rename(from, to)
    fun mkdirs(path: String): Boolean = s().mkdirs(path)

    fun openRead(path: String): InputStream {
        val pfd = s().openRead(path) ?: throw IOException("Cannot read $path")
        return ParcelFileDescriptor.AutoCloseInputStream(pfd)
    }

    fun openWrite(path: String): OutputStream {
        val pfd = s().openWrite(path) ?: throw IOException("Cannot write $path")
        return ParcelFileDescriptor.AutoCloseOutputStream(pfd)
    }
}

class Stat(val exists: Boolean, val dir: Boolean, val size: Long, val mod: Long)

/**
 * File operations that work on normal folders AND on Android/data + Android/obb
 * (through Shizuku). All functions are blocking: call them from Dispatchers.IO.
 */
object Fs {
    private val rx = Regex("^(/storage/emulated/\\d+|/storage/[^/]+|/sdcard|/mnt/sdcard)/Android/(data|obb)(/.*)?$")

    /** True for Android/data and Android/obb (normal apps are blocked there on Android 11+). */
    fun restricted(f: File): Boolean = Build.VERSION.SDK_INT >= 30 && rx.matches(f.path)

    private fun viaPriv(f: File): Boolean = restricted(f) && Priv.ready

    fun stat(f: File): Stat {
        if (viaPriv(f)) {
            val a = Priv.stat(f.path)
            return Stat(a[0] != 0L, a[0] == 2L, a[1], a[2])
        }
        return Stat(f.exists(), f.isDirectory, f.length(), f.lastModified())
    }

    fun exists(f: File): Boolean = if (viaPriv(f)) Priv.stat(f.path)[0] != 0L else f.exists()
    fun isDir(f: File): Boolean = if (viaPriv(f)) Priv.stat(f.path)[0] == 2L else f.isDirectory

    fun list(dir: File): List<Item>? {
        if (viaPriv(dir)) {
            return try {
                Priv.list(dir.path)
            } catch (e: Throwable) {
                null
            }
        }
        return dir.listFiles()?.map { it.toItem() }
    }

    fun delete(f: File) {
        val ok = if (viaPriv(f)) Priv.delete(f.path) else f.deleteRecursively()
        if (!ok) throw IOException("Could not delete ${f.name}")
    }

    fun rename(a: File, b: File): Boolean =
        if (viaPriv(a) && viaPriv(b)) Priv.rename(a.path, b.path) else a.renameTo(b)

    fun mkdirs(f: File) {
        if (viaPriv(f)) Priv.mkdirs(f.path) else f.mkdirs()
    }

    fun openIn(f: File): InputStream = if (viaPriv(f)) Priv.openRead(f.path) else FileInputStream(f)

    fun openOut(f: File): OutputStream {
        if (viaPriv(f)) return Priv.openWrite(f.path)
        f.parentFile?.mkdirs()
        return FileOutputStream(f)
    }

    fun unique(f: File): File {
        if (!exists(f)) return f
        val base = f.name.substringBefore('.')
        val ext = f.name.removePrefix(base)
        var i = 1
        while (true) {
            val c = File(f.parentFile, "$base ($i)$ext")
            if (!exists(c)) return c
            i++
        }
    }

    fun copyTree(src: File, dst: File) {
        if (dst.path == src.path || dst.path.startsWith(src.path + "/")) {
            throw IOException("Cannot copy a folder into itself")
        }
        if (isDir(src)) {
            mkdirs(dst)
            list(src)?.forEach { copyTree(it.file, File(dst, it.file.name)) }
        } else {
            openIn(src).use { i -> openOut(dst).use { o -> i.copyTo(o) } }
        }
    }

    fun move(src: File, dst: File) {
        if (!rename(src, dst)) {
            copyTree(src, dst)
            delete(src)
        }
    }

    fun sizeOf(f: File): Long {
        if (!viaPriv(f)) return f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        val st = stat(f)
        if (!st.dir) return st.size
        return list(f)?.sumOf { if (it.dir) sizeOf(it.file) else it.size } ?: 0L
    }

    /** Returns a normal, readable copy of a file (copies it to cache if it is in Android/data). */
    fun localCopy(f: File, cache: File): File {
        if (!viaPriv(f)) return f
        val dest = File(cache, "priv_view/${System.nanoTime()}/${f.name}")
        dest.parentFile?.mkdirs()
        openIn(f).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        return dest
    }
}
