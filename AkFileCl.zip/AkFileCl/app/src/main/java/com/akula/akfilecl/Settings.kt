@file:OptIn(ExperimentalMaterial3Api::class)

package com.akula.akfilecl

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** All app settings. Stored in the same "ak" preferences file as v2 (your old settings are kept). */
object AppSettings {
    private var prefs: SharedPreferences? = null

    var grid by mutableStateOf(false)
        private set
    var sort by mutableStateOf(SortBy.Name)
        private set
    var showHidden by mutableStateOf(false)
        private set
    var showTime by mutableStateOf(true)
        private set
    var h24 by mutableStateOf(true)
        private set
    var quickView by mutableStateOf(true)
        private set

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("ak", 0)
        prefs = p
        grid = p.getBoolean("grid", false)
        sort = SortBy.values().getOrElse(p.getInt("sort", 0)) { SortBy.Name }
        showHidden = p.getBoolean("hidden", false)
        showTime = p.getBoolean("showTime", true)
        h24 = p.getBoolean("h24", android.text.format.DateFormat.is24HourFormat(ctx))
        quickView = p.getBoolean("quickView", true)
    }

    private fun save(key: String, v: Boolean) {
        prefs?.edit()?.putBoolean(key, v)?.apply()
    }

    fun setGrid(v: Boolean) { grid = v; save("grid", v) }
    fun setSort(v: SortBy) { sort = v; prefs?.edit()?.putInt("sort", v.ordinal)?.apply() }
    fun setShowHidden(v: Boolean) { showHidden = v; save("hidden", v) }
    fun setShowTime(v: Boolean) { showTime = v; save("showTime", v) }
    fun setH24(v: Boolean) { h24 = v; save("h24", v) }
    fun setQuickView(v: Boolean) { quickView = v; save("quickView", v) }
}

@Composable
private fun SettingsHeader(t: String) {
    Text(
        t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyLarge)
            Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun <T> ChipsRow(title: String, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
            }
        }
    }
}

@Composable
fun SettingsScreen(
    mode: ThemeMode, onTheme: (ThemeMode) -> Unit, onShizuku: () -> Unit, modifier: Modifier = Modifier
) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        SettingsHeader("Appearance")
        ChipsRow("Theme", ThemeMode.values().toList(), mode, { it.label }, onTheme)
        ChipsRow("Default view", listOf(false, true), AppSettings.grid, { if (it) "Grid" else "List" }) {
            AppSettings.setGrid(it)
        }
        SwitchRow("Show time", "Show the time (hh:mm) next to the date in file lists", AppSettings.showTime) {
            AppSettings.setShowTime(it)
        }
        SwitchRow("24-hour clock", "Off = 12-hour with AM/PM", AppSettings.h24) { AppSettings.setH24(it) }

        SettingsHeader("Files")
        ChipsRow("Default sort", SortBy.values().toList(), AppSettings.sort, { it.label }) { AppSettings.setSort(it) }
        SwitchRow("Show hidden files", "Files and folders that start with a dot", AppSettings.showHidden) {
            AppSettings.setShowHidden(it)
        }
        SwitchRow(
            "Built-in viewer on tap", "Tap a text or image file to open it inside AkFileCl",
            AppSettings.quickView
        ) { AppSettings.setQuickView(it) }

        SettingsHeader("Shizuku")
        Row(
            Modifier.fillMaxWidth().clickable { onShizuku() }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Bolt, null, tint = shizukuColor(Priv.status))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(Priv.status.label, color = MaterialTheme.colorScheme.onSurface)
                Text(
                    "Needed to open Android/data and Android/obb",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onShizuku) { Text("Manage") }
        }

        SettingsHeader("About")
        Text(
            "AkFileCl 3.0  -  Akula team + Claude",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}
