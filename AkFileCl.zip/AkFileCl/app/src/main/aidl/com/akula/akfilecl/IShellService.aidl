package com.akula.akfilecl;

import android.os.ParcelFileDescriptor;

interface IShellService {
    void destroy() = 16777114;
    String[] list(String path) = 1;
    long[] stat(String path) = 2;
    boolean delete(String path) = 3;
    boolean rename(String from, String to) = 4;
    boolean mkdirs(String path) = 5;
    ParcelFileDescriptor openRead(String path) = 6;
    ParcelFileDescriptor openWrite(String path) = 7;
    int uid() = 8;
}
